"use client";

import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase-browser";
import renderDynamicField from "../renderDynamicField";
import { getTemplate } from "@/templates/sections/loader.server";
import type { TemplateWithSlug } from "@/templates/sections/loader.server";
import OpenPreviewButton from "../../components/ui/OpenPreviewButton";
import PreviewSite from "../../components/PreviewSite";

/* -------------------------------------------------------------------------- */
/*                                   TYPES                                    */
/* -------------------------------------------------------------------------- */

interface TemplateFieldBase {
  type: string;
  name: string;
  label?: string;
}

interface TemplateFieldSingle extends TemplateFieldBase {
  type: "text" | "textarea" | "number" | "image";
}

interface TemplateFieldRepeater extends TemplateFieldBase {
  type: "repeater";
  fields: TemplateFieldSingle[];
  min?: number;
  max?: number;
}

type TemplateField = TemplateFieldSingle | TemplateFieldRepeater;

interface SiteSection {
  id: number;
  slug: string;
  title: string;
  table_name: string;
  template_slug: string | null;
}

interface DBRow {
  id: string;
  section_slug: string;
  content: Record<string, unknown>;
  display_order?: number;
  price_ht?: number;
  price_ttc?: number;
  tva_rate?: number;
  offer_id?: string;
  [key: string]: unknown;
}

/* -------------------------------------------------------------------------- */

export default function SectionEditorWrapper({ slug }: { slug: string }) {
  const supabase = supabaseBrowser();

  const [section, setSection] = useState<SiteSection | null>(null);

  // 🔥 FIX ICI : on remplace TemplateSchema par TemplateWithSlug
  const [template, setTemplate] = useState<TemplateWithSlug | null>(null);

  const [formData, setFormData] = useState<Record<string, unknown> | null>(null);
  const [rows, setRows] = useState<DBRow[]>([]);

  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");


  /* -------------------------------------------------------------------------- */
  /*                           LOAD SECTION + TEMPLATE                          */
  /* -------------------------------------------------------------------------- */

  const load = async () => {
    setLoading(true);

    // SECTION
    const { data: sectionData } = await supabase
      .from("site_sections")
      .select("*")
      .eq("slug", slug)
      .single();

    if (!sectionData) {
      setMessage("Section introuvable");
      setLoading(false);
      return;
    }

    setSection(sectionData);

    // TEMPLATE
    const tpl = sectionData.template_slug
      ? await getTemplate(sectionData.template_slug)
      : null;

    setTemplate(tpl);

    // ROWS
    const { data: rowsData } = await supabase
      .from(sectionData.table_name)
      .select("*")
      .eq("section_slug", slug)
      .order("display_order", { ascending: true });

    const fetchedRows: DBRow[] = rowsData ?? [];
    setRows(fetchedRows);

    /* ------------------------------- FORM DATA ------------------------------- */

    if (!tpl) {
      setLoading(false);
      return;
    }

    const repeaterField = tpl.fields.find(
      (f): f is TemplateFieldRepeater => f.type === "repeater"
    );

    if (repeaterField) {
      const valueArray = fetchedRows.map((row) => {
        const base: Record<string, unknown> = row.content ?? {};

        return {
          ...base,
          ...(row.price_ht !== undefined && { price_ht: row.price_ht }),
          ...(row.price_ttc !== undefined && { price_ttc: row.price_ttc }),
          ...(row.tva_rate !== undefined && { tva_rate: row.tva_rate }),
          ...(row.offer_id !== undefined && { offer_id: row.offer_id }),
        };
      });

      setFormData({ [repeaterField.name]: valueArray });
    } else {
      const row = fetchedRows[0] ?? { content: {} };
      setFormData(row.content ?? {});
    }

    setLoading(false);
  };

  useEffect(() => {
    load();
  }, [slug]);

  /* -------------------------------------------------------------------------- */
  /*                                   SAVE                                    */
  /* -------------------------------------------------------------------------- */

  const save = async () => {
    if (!section || !template) return;

    const table = section.table_name;

    const repeaterField = template.fields.find(
      (f): f is TemplateFieldRepeater => f.type === "repeater"
    );

    /* -------------------------------- REPEATER ------------------------------- */

    if (repeaterField) {
      const items = (formData?.[repeaterField.name] as Record<string, unknown>[]) ?? [];
      const existing = [...rows];

      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        const existingRow = existing[i];

        const contentFields: Record<string, unknown> = {};

        repeaterField.fields.forEach((f) => {
          const fieldName = f.name;

          if (
            ["text", "textarea", "number"].includes(f.type) &&
            !["price_ht", "price_ttc", "tva_rate"].includes(fieldName)
          ) {
            contentFields[fieldName] = item[fieldName];
          }
        });

        const payload: Record<string, unknown> = {
          section_slug: slug,
          content: contentFields,
          display_order: i + 1,
        };

        if (item.price_ht !== undefined) payload.price_ht = item.price_ht;
        if (item.price_ttc !== undefined) payload.price_ttc = item.price_ttc;
        if (item.tva_rate !== undefined) payload.tva_rate = item.tva_rate;
        if (item.offer_id !== undefined) payload.offer_id = item.offer_id;

        if (existingRow) {
          await supabase.from(table).update(payload).eq("id", existingRow.id);
        } else {
          await supabase.from(table).insert(payload);
        }
      }

      // DELETE removed rows
      if (items.length < rows.length) {
        const toDelete = rows.slice(items.length);
        for (const row of toDelete) {
          await supabase.from(table).delete().eq("id", row.id);
        }
      }

      setMessage("Section sauvegardée.");
      load();
      return;
    }

    /* -------------------------------- SIMPLE -------------------------------- */

    const row = rows[0];

    const { error } = await supabase
      .from(table)
      .update({ content: formData })
      .eq("id", row.id);

    setMessage(error ? error.message : "Section sauvegardée.");
    load();
  };

  /* -------------------------------------------------------------------------- */
  /*                                   RENDER                                  */
  /* -------------------------------------------------------------------------- */

  if (loading || !section || !template || !formData) {
    return <p className="text-neutral-400">Chargement...</p>;
  }

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-white">Édition : {section.title}</h1>

      <div className="bg-neutral-900 p-6 rounded-lg flex flex-col gap-6">
        {template.fields.map((field) => (
          <div key={field.name}>
            {renderDynamicField({
              field,
              value: formData[field.name],
              onChange: (newVal) =>
                setFormData({
                  ...formData,
                  [field.name]: newVal,
                }),
            })}
          </div>
        ))}

        <button
          onClick={save}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-500"
        >
          Sauvegarder
        </button>

        {message && <p className="text-green-400 mt-2">{message}</p>}
      </div>

      <div className="hidden md:block">
        <PreviewSite />
      </div>

      <div className="mt-4 flex justify-end md:hidden">
        <OpenPreviewButton href="/" />
      </div>
    </div>
  );
}
