"use client";

import renderDynamicField from "./renderDynamicField";

export default function RepeaterEditor({
  field,
  value,
  onChange
}: {
  field: any;
  value: any[];
  onChange: (newValue: any[]) => void;
}) {

  const items = value ?? [];

  const addItem = () => {
    // FIX TYPE SCRIPT: objet indexable
    const emptyItem: Record<string, any> = {};

    field.fields.forEach((f: any) => {
      emptyItem[f.name] = f.type === "number" ? 0 : "";
    });

    onChange([...items, emptyItem]);
  };

  const updateItem = (index: number, newVal: any) => {
    const updated = [...items];
    updated[index] = newVal;
    onChange(updated);
  };

  const deleteItem = (index: number) => {
    const updated = items.filter((_, i) => i !== index);
    onChange(updated);
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex justify-between items-center">
        <h4 className="text-neutral-200 text-sm">{field.label}</h4>
        <button
          type="button"
          onClick={addItem}
          className="px-2 py-1 rounded bg-neutral-700 text-neutral-100 text-xs hover:bg-neutral-600"
        >
          + Ajouter
        </button>
      </div>

      {items.map((item, index) => (
        <div
          key={index}
          className="border border-neutral-700 rounded-lg p-4 flex flex-col gap-3 bg-neutral-800"
        >
          <div className="flex justify-between mb-1">
            <span className="text-neutral-400 text-sm">Élément {index + 1}</span>

            <button
              type="button"
              onClick={() => deleteItem(index)}
              className="text-red-400 text-xs hover:text-red-600"
            >
              Supprimer
            </button>
          </div>

          {field.fields.map((subField: any) => (
            <div key={subField.name}>
              {renderDynamicField({
                field: subField,
                value: item[subField.name],
                onChange: (newVal) =>
                  updateItem(index, { ...item, [subField.name]: newVal })
              })}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
