'use client'
import ProfileEditor from '../components/ProfileEditor'

export default function ProfilPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Mon profil / Qui sommes nous?</h1>
      <ProfileEditor />
    </div>
  )
}
