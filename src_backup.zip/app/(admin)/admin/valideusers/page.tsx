'use client'

import { useEffect, useState } from 'react'
import { supabaseBrowser } from "@/lib/supabase-browser";

export default function ValideUsers() {
  
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Valider un nouvel utilisateur</h1>

      
    </div>
  )
}
