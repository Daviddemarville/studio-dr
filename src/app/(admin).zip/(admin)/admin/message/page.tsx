'use client'

import { useEffect, useState } from 'react'
import { supabaseBrowser } from "@/lib/supabase-browser";

export default function Message() {
  
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Administrer les mails reçus</h1>

      
    </div>
  )
}
