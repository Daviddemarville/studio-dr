"use client";

import { resetRequestSchema } from "@/lib/zod/resetSchema";
import { useForm } from "react-hook-form";
import { supabaseBrowser } from "@/lib/supabase-browser";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "react-toastify";

export default function ResetRequestForm() {
  const supabase = supabaseBrowser();

  const { register, handleSubmit, reset } = useForm({
    resolver: zodResolver(resetRequestSchema),
  });

  const onSubmit = async (data: any) => {
    const { error } = await supabase.auth.resetPasswordForEmail(data.email, {
      redirectTo: `${window.location.origin}/reset-confirm`,
    });

    if (error) {
      toast.error(error.message);
    } else {
      toast.success("Si un compte existe avec cet email, un lien vous a été envoyé.");
      reset({ email: "" });
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 text-white">
      
      <input
        {...register("email")}
        type="email"
        className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700 focus:border-blue-500"
        placeholder="Email"
      />

      <button
        type="submit"
        className="w-full bg-blue-600 hover:bg-blue-700 py-2 rounded-lg text-white"
      >
        Envoyer le lien
      </button>
    </form>
  );
}
