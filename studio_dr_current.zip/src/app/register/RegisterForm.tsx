"use client";

import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "react-toastify";

const schema = z.object({
  firstname: z.string().min(2, "Prénom trop court"),
  lastname: z.string().min(2, "Nom trop court"),
  pseudo: z.string().min(3, "3 caractères min").optional(),
  email: z.string().email("Email invalide"),
  password: z.string().min(8, "8 caractères minimum"),
  confirm: z.string(),
}).refine((data) => data.password === data.confirm, {
  path: ["confirm"],
  message: "Les mots de passe ne correspondent pas",
});

export default function RegisterForm() {
  const { register, handleSubmit } = useForm({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: any) => {
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    const json = await res.json();

    if (!res.ok) {
      toast.error(json.error || "Erreur.");
      return;
    }

    toast.success("Compte créé ! Vérifiez vos emails.");
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 text-white">

      <div className="flex gap-4">
        <input
          {...register("firstname")}
          className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700"
          placeholder="Prénom"
        />

        <input
          {...register("lastname")}
          className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700"
          placeholder="Nom"
        />
      </div>

      <input
        {...register("pseudo")}
        className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700"
        placeholder="Pseudo (optionnel)"
      />

      <input
        {...register("email")}
        className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700"
        placeholder="Email"
      />

      <input
        {...register("password")}
        type="password"
        className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700"
        placeholder="Mot de passe"
      />

      <input
        {...register("confirm")}
        type="password"
        className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700"
        placeholder="Confirmer le mot de passe"
      />

      <button className="w-full bg-green-600 hover:bg-green-700 py-2 rounded-lg text-white">
        Créer le compte
      </button>

      <p className="text-sm text-center text-gray-400">
        Déjà un compte ?{" "}
        <a href="/login" className="text-blue-400 hover:underline">
          Se connecter
        </a>
      </p>
    </form>
  );
}
