"use client";

import { resetConfirmSchema } from "@/lib/zod/resetSchema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { supabaseBrowser } from "@/lib/supabase-browser";
import { toast } from "react-toastify";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function ResetConfirmForm() {
  const supabase = supabaseBrowser();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, reset } = useForm({
    resolver: zodResolver(resetConfirmSchema),
  });

  const onSubmit = async (data: any) => {
    setLoading(true);

    const { error } = await supabase.auth.updateUser({
      password: data.password,
    });

    if (error) {
      toast.error(error.message);
      setLoading(false);
      return;
    }

    toast.success("Mot de passe mis à jour !");
    reset();

    setTimeout(() => router.push("/login"), 500);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 text-white">

      <input
        {...register("password")}
        type="password"
        className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700 focus:border-blue-500"
        placeholder="Nouveau mot de passe"
      />

      <input
        {...register("confirm")}
        type="password"
        className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700 focus:border-blue-500"
        placeholder="Confirmer"
      />

      <button
        type="submit"
        disabled={loading}
        className={`w-full py-2 rounded-lg text-white ${
          loading
            ? "bg-blue-800 cursor-not-allowed"
            : "bg-blue-600 hover:bg-blue-700"
        }`}
      >
        {loading ? "Mise à jour..." : "Mettre à jour"}
      </button>
    </form>
  );
}
