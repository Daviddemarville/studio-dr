"use client";

import { supabaseBrowser } from "@/lib/supabase-browser";
import { FcGoogle } from "react-icons/fc";
import { FaDiscord, FaGithub } from "react-icons/fa";

export default function OAuthButtons() {
  const supabase = supabaseBrowser();

  const loginWith = async (provider: "google" | "github" | "discord") => {
    await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
      },
    });
  };

  return (
    <div className="space-y-2">
      <button
        onClick={() => loginWith("google")}
        className="w-full bg-white text-black py-2 rounded-lg flex justify-center items-center gap-2 hover:bg-gray-100"
      >
        <FcGoogle size={20} /> Continuer avec Google
      </button>

      <button
        onClick={() => loginWith("github")}
        className="w-full bg-[#0D1117] text-white py-2 rounded-lg flex justify-center items-center gap-2 hover:bg-gray-800"
      >
        <FaGithub size={18} /> Continuer avec GitHub
      </button>

      <button
        onClick={() => loginWith("discord")}
        className="w-full bg-[#5865F2] text-white py-2 rounded-lg flex justify-center items-center gap-2 hover:bg-[#4752c4]"
      >
        <FaDiscord size={18} /> Continuer avec Discord
      </button>
    </div>
  );
}
