"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema } from "@/lib/zod/loginSchema";
import { supabaseBrowser } from "@/lib/supabase-browser";
import { toast } from "react-toastify";
import OAuthButtons from "../components/ui/OAuthButtons";
import { useRouter } from "next/navigation";

export default function LoginForm() {
  const supabase = supabaseBrowser();
  const router = useRouter();

  const { register, handleSubmit } = useForm({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: any) => {
    const { data: auth, error } = await supabase.auth.signInWithPassword({
      email: data.email,
      password: data.password,
    });

    if (error) return toast.error(error.message);
    if (!auth.user) return toast.error("Erreur interne.");

    // Vérifier approval
    const { data: userData } = await supabase
      .from("users")
      .select("is_approved, firstname, lastname, pseudo")
      .eq("id", auth.user.id)
      .single();

    if (!userData?.is_approved) {
      await supabase.auth.signOut();
      return toast.warning("Votre compte est en attente de validation.");
    }

    toast.success("Connexion réussie !");
    router.push("/admin");
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">

      <OAuthButtons />

      <div className="flex items-center gap-4">
        <div className="h-px bg-gray-700 w-full" />
        <span className="text-xs text-gray-400">ou</span>
        <div className="h-px bg-gray-700 w-full" />
      </div>

      <input
        {...register("email")}
        className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700 focus:border-blue-500"
        placeholder="Email"
      />

      <input
        {...register("password")}
        type="password"
        className="w-full p-3 rounded-lg bg-[#111317] border border-gray-700 focus:border-blue-500"
        placeholder="Mot de passe"
      />

      <button
        type="submit"
        className="w-full bg-blue-600 hover:bg-blue-700 py-2 rounded-lg"
      >
        Se connecter
      </button>

      <div className="flex justify-between text-sm">
        <a href="/reset" className="text-blue-400 hover:underline">
          Mot de passe oublié ?
        </a>
        <a href="/register" className="text-gray-400 hover:underline">
          Créer un compte
        </a>
      </div>
    </form>
  );
}
